export class LoginPage
{
    constructor(page)
    {
        this.page=page
        this.username=page.locator('//input[@id="user-name"]')
        this.password=page.locator('//input[@id="password"]')
        this.login=page.locator('//input[@id="login-button"]')
      //  this.errormessage=page.locator('.data-test="error"')
    }
    async openApplication()
    {
        await this.page.goto('https://www.saucedemo.com/')
    }
    async clickLogin()
    {
        await this.username.fill('standard_user')
        await this.password.fill('secret_sauce')
        await this.login.click()
    }
}